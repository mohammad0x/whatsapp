import { Injectable, OnModuleInit } from '@nestjs/common';
import makeWASocket, { DisconnectReason, useMultiFileAuthState } from '@whiskeysockets/baileys';
import * as QRCode from 'qrcode';
import pino from 'pino';
import * as fs from 'fs';
import axios from 'axios';
import { PrismaService } from '../prisma/prisma.service';
import { ChatbotService } from './chatbot.service';

@Injectable()
export class WhatsappService implements OnModuleInit {
  private sessions = new Map<string, any>();
  private qrCodes = new Map<string, string>();

  constructor(
    private prisma: PrismaService,
    private chatbotService: ChatbotService
  ) {}

  // 🔄 شروع برنامه
  async onModuleInit() {
    const authDir = 'auth_info';
    if (fs.existsSync(authDir)) {
      const folders = fs.readdirSync(authDir);
      for (const sessionId of folders) {
        if(fs.existsSync(`${authDir}/${sessionId}/creds.json`)) {
             console.log(`🔄 Recovering: ${sessionId}`);
             await this.createSession(sessionId, 0, false);
        }
      }
    }
  }

  // 📊 وضعیت
  async getSessionStatus(sessionId: string, userId: number) {
    const sock = this.sessions.get(sessionId);
    if(sock?.user) return { status: 'CONNECTED', qr: null, phone: sock.user.id.split(':')[0] };
    
    const qr = this.qrCodes.get(sessionId);
    if (qr) return { status: 'SCAN_QR', qr };

    return { status: 'INITIALIZING', qr: null };
  }

  // 🔥 ساخت اتصال
  async createSession(sessionId: string, userId: number, isNew = true) {
    const authFolder = `auth_info/${sessionId}`;
    const { state, saveCreds } = await useMultiFileAuthState(authFolder);

    const sock = makeWASocket({
      auth: state,
      logger: pino({ level: 'silent' }) as any, 
      connectTimeoutMs: 60000,
      browser: ['Whatsapp Panel', 'Chrome', '1.0.0'],
    });

    this.sessions.set(sessionId, sock);

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        console.log(`📷 Scan QR for: ${sessionId}`);
        const qrImage = await QRCode.toDataURL(qr);
        this.qrCodes.set(sessionId, qrImage);
        if (isNew) await this.saveSessionToDb(sessionId, 'SCAN_QR', userId);
      }

      if (connection === 'open') {
        console.log(`✅ Session ${sessionId} CONNECTED!`);
        this.qrCodes.delete(sessionId);
        const myPhone = sock.user?.id?.split(':')[0];
        if (isNew) await this.saveSessionToDb(sessionId, 'CONNECTED', userId, myPhone);
      }
      
      if (connection === 'close') {
          const shouldReconnect = (lastDisconnect?.error as any)?.output?.statusCode !== DisconnectReason.loggedOut;
          if (shouldReconnect) {
              setTimeout(() => this.createSession(sessionId, userId, isNew), 3000);
          } else {
              console.log(`❌ Session ${sessionId} Logged Out.`);
              this.sessions.delete(sessionId);
              try { fs.rmSync(authFolder, { recursive: true, force: true }); } catch(e) {}
              await this.prisma.session.update({ where: { id: sessionId }, data: { status: 'DISCONNECTED' } }).catch(() => {});
          }
      }
    });

    sock.ev.on('creds.update', saveCreds);

    // 📩 مدیریت پیام‌های دریافتی (اصلاح شده برای رفع خطای TS)
    // 📩 مدیریت پیام‌ها (تست مستقیم و بدون واسطه)
    // 📩 مدیریت پیام‌ها (اصلاح شده برای مشکل LID)
    // 📩 مدیریت پیام‌ها (نسخه نهایی و سازگار با همه آیدی‌ها)
    sock.ev.on('messages.upsert', async (m) => {
      try {
        const msg = m.messages[0];
        if (!msg.message) return;
        
        const senderJid = msg.key.remoteJid;
        if (!senderJid) return;

        // 🛑 نادیده گرفتن پیام‌های وضعیت و گروه‌ها
        if (senderJid === 'status@broadcast' || senderJid.includes('@g.us')) return;

        const isFromMe = msg.key.fromMe;
        const text = msg.message.conversation || 
                     msg.message.extendedTextMessage?.text || 
                     msg.message.imageMessage?.caption || '';

        // اگر متن نبود یا پیام از خودم بود (که ربات فرستاده)، بیخیال شو
        if (!text || isFromMe) return;

        console.log(`📨 Received: "${text}" | JID: ${senderJid}`);

        // ✅ تشخیص کاربر (هم شماره عادی و هم LID را قبول می‌کنیم)
        const isUser = senderJid.endsWith('@s.whatsapp.net') || senderJid.endsWith('@lid');
        
        if (isUser) {
            // برای منطق ربات، سعی می‌کنیم شماره تمیز را داشته باشیم
            // اما برای ارسال پیام، از همان آدرس اصلی (senderJid) استفاده می‌کنیم
            let phoneForLogic = senderJid.split('@')[0];
            
            // اگر آیدی عجیب و غریب بود (LID)، همان را به عنوان شناسه نگه دار
            if (senderJid.includes('@lid')) {
                phoneForLogic = 'USER_LID_' + phoneForLogic.substring(0, 6); // فقط برای نمایش
            }

            // فراخوانی ربات
            const botReply = this.chatbotService.getResponse(phoneForLogic, text);

            if (botReply) {
                // ارسال وضعیت تایپ
                await sock.sendPresenceUpdate('composing', senderJid);
                await new Promise(r => setTimeout(r, 800));
                
                // 🚀 نکته حیاتی: ارسال به همان آدرسی که پیام داده (بدون تغییر)
                console.log(`📤 Sending reply to: ${senderJid}`);
                await sock.sendMessage(senderJid, { text: botReply });
                
                // ذخیره در دیتابیس
                await this.prisma.message.create({
                    data: { 
                        text: botReply, 
                        sender: 'BOT', 
                        receiver: phoneForLogic, // ذخیره شناسه برای گزارش
                        isFromMe: true, 
                        type: 'text', 
                        sessionId 
                    }
                }).catch(() => {});
            }

            // ذخیره پیام کاربر
            await this.prisma.message.create({
                data: { 
                    text, 
                    sender: phoneForLogic, 
                    receiver: 'ME', 
                    isFromMe: false, 
                    type: 'text', 
                    sessionId 
                }
            }).catch(() => {});
        }
      } catch (error) {
          console.error('❌ Message Error:', error);
      }
    });
  }

  // 🚀 ارسال پیام متنی
  async sendTextMessage(sessionId: string, phone: string, message: string, userId: number) {
    let sock = this.sessions.get(sessionId);
    const formattedPhone = phone.replace(/\D/g, '').replace(/^0/, '98');
    const jid = `${formattedPhone}@s.whatsapp.net`;

    try {
        if (!sock) {
             await this.createSession(sessionId, userId, false);
             await new Promise(r => setTimeout(r, 2000));
             sock = this.sessions.get(sessionId);
        }
        await this.waitForConnection(sock);
        await sock.sendMessage(jid, { text: message });

    } catch (error) {
        console.warn(`⚠️ Retry sending...`);
        this.sessions.delete(sessionId);
        await this.createSession(sessionId, userId, false);
        await new Promise(r => setTimeout(r, 4000));
        sock = this.sessions.get(sessionId);
        await this.waitForConnection(sock);
        await sock.sendMessage(jid, { text: message });
    }

    await this.prisma.message.create({
        data: { text: message, sender: 'ME', receiver: formattedPhone, isFromMe: true, type: 'text', sessionId }
    });
    return { status: 'sent', phone: formattedPhone };
  }

  // 📷 ارسال عکس
  async sendImageBuffer(sessionId: string, phone: string, fileBuffer: Buffer, caption: string, userId: number) {
    let sock = this.sessions.get(sessionId);
    const formattedPhone = phone.replace(/\D/g, '').replace(/^0/, '98');
    const jid = `${formattedPhone}@s.whatsapp.net`;

    if (!Buffer.isBuffer(fileBuffer) || fileBuffer.length === 0) throw new Error('File Error');

    try {
        if (!sock) {
             await this.createSession(sessionId, userId, false);
             await new Promise(r => setTimeout(r, 2000));
             sock = this.sessions.get(sessionId);
        }
        await this.waitForConnection(sock);
        await sock.sendMessage(jid, { image: fileBuffer, caption, mimetype: 'image/jpeg' });

    } catch (error) {
        console.warn(`⚠️ Retry Image...`);
        this.sessions.delete(sessionId);
        await this.createSession(sessionId, userId, false);
        await new Promise(r => setTimeout(r, 5000));
        sock = this.sessions.get(sessionId);
        await this.waitForConnection(sock);
        await sock.sendMessage(jid, { image: fileBuffer, caption, mimetype: 'image/jpeg' });
    }

    await this.prisma.message.create({
        data: { text: caption || '[IMAGE]', sender: 'ME', receiver: formattedPhone, isFromMe: true, type: 'image', sessionId }
    });
    return { status: 'sent', type: 'image' };
  }

  // 📂 ارسال فایل
  async sendDocumentMessage(sessionId: string, phone: string, fileUrl: string, fileName: string, caption: string, userId: number) {
    let sock = this.sessions.get(sessionId);
    const formattedPhone = phone.replace(/\D/g, '').replace(/^0/, '98');
    const jid = `${formattedPhone}@s.whatsapp.net`;

    let buffer: Buffer;
    let mimetype: string = 'application/octet-stream';

    try {
        if (fileUrl.startsWith('http')) {
            const response = await axios.get(fileUrl, { responseType: 'arraybuffer' });
            buffer = Buffer.from(response.data, 'binary');
            mimetype = response.headers['content-type'] || 'application/pdf';
        } else {
            if (!fs.existsSync(fileUrl)) throw new Error(`File not found: ${fileUrl}`);
            buffer = fs.readFileSync(fileUrl);
        }
    } catch (e) { throw new Error(e.message); }

    try {
        if (!sock) {
             await this.createSession(sessionId, userId, false);
             await new Promise(r => setTimeout(r, 2000));
             sock = this.sessions.get(sessionId);
        }
        await this.waitForConnection(sock);
        await sock.sendMessage(jid, { document: buffer, mimetype, fileName, caption });

    } catch (error) {
        this.sessions.delete(sessionId);
        await this.createSession(sessionId, userId, false);
        await new Promise(r => setTimeout(r, 5000));
        sock = this.sessions.get(sessionId);
        await this.waitForConnection(sock);
        await sock.sendMessage(jid, { document: buffer, mimetype, fileName, caption });
    }

    await this.prisma.message.create({
        data: { text: caption || `[FILE: ${fileName}]`, sender: 'ME', receiver: formattedPhone, isFromMe: true, type: 'document', sessionId }
    });
    return { status: 'success' };
  }

  // --- ابزارها ---
  async getContacts(sessionId: string) {
    const messages = await this.prisma.message.findMany({
        where: { sessionId }, orderBy: { createdAt: 'desc' }, distinct: ['sender', 'receiver']
    });
    const contacts = new Map();
    messages.forEach(msg => {
        const p = msg.isFromMe ? msg.receiver : msg.sender;
        if (p !== 'ME' && !contacts.has(p)) contacts.set(p, { phone: p, lastMessage: msg.text });
    });
    return Array.from(contacts.values());
  }

  async getChatHistory(sessionId: string, phone: string) {
    const clean = phone.replace(/\D/g, ''); 
    return this.prisma.message.findMany({
        where: { sessionId, OR: [{ sender: clean }, { receiver: clean }] },
        orderBy: { createdAt: 'asc' }
    });
  }

  async setWebhook(sessionId: string, url: string, userId: number) {
    await this.prisma.session.update({ where: { id: sessionId }, data: { webhookUrl: url } });
    return { message: 'OK' };
  }

  async getSessionIdByUser(userId: number) {
    const s = await this.prisma.session.findFirst({ where: { userId } });
    return s ? s.id : 'main';
  }

  private async saveSessionToDb(id: string, status: string, userId: number, phone?: string) {
    if(userId === 0) return;
    try { await this.prisma.session.upsert({ where: { id }, update: { status, phone }, create: { id, status, phone, userId } }); } catch(e){}
  }

  private async waitForConnection(sock: any): Promise<void> {
    if (sock?.user && sock?.ws?.isOpen) return;
    for(let i=0; i<20; i++) {
        if (sock?.user && sock?.ws?.isOpen) return;
        await new Promise(r => setTimeout(r, 1000));
    }
    throw new Error('Connection timed out');
  }
}